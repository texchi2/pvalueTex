#' Retrieve miRSeq data from firebrowseR (TCGA)
#' https://github.com/mariodeng/FirebrowseR/blob/master/R/Samples.miRSeq.R
#' 
#' This service returns sample-level log2 miRSeq expression values. Results may be filtered by miR, cohort, barcode, sample type or Firehose preprocessing tool, but at least one miR must be supplied.
#'
#' @param format Format of result. Default value is json. While json,tsv,csv are available. 
#' @param mir Comma separated list of miR names (e.g. hsa-let-7b-5p,hsa-let-7a-1). Multiple values are allowed .
#' @param cohort Narrow search to one or more TCGA disease cohorts from the scrollable list. Multiple values are allowed ACC,BLCA,BRCA,CESC,CHOL,COAD,COADREAD,DLBC,ESCA,FPPP,GBM,GBMLGG,HNSC,KICH,KIPAN,KIRC,KIRP,LAML,LGG,LIHC,LUAD,LUSC,MESO,OV,PAAD,PCPG,PRAD,READ,SARC,SKCM,STAD,STES,TGCT,THCA,THYM,UCEC,UCS,UVM.
#' @param tcga_participant_barcode Comma separated list of TCGA participant barcodes (e.g. TCGA-GF-A4EO). Multiple values are allowed .
#' @param tool Narrow search to include only data/results produced by the selected Firehose tool. Multiple values are allowed miRseq_Mature_Preprocess,miRseq_Preprocess. Default value is miRseq_Mature_Preprocess.  
#' @param sample_type Narrow search to one or more TCGA sample types from the scrollable list. Multiple values are allowed NB,NBC,NBM,NT,TAM,TAP,TB,TM,TP,TR.
#' @param page Which page (slice) of entire results set should be returned.  Multiple values are allowed . Default value is 1.  
#' @param page_size Number of records per page of results.  Max is 2000. Multiple values are allowed . Default value is 250.  
#' @param sort_by Which column in the results should be used for sorting paginated results? Default value is cohort. While tcga_participant_barcode,cohort,tool,mir,sample_type are available. 
#' 
#' @export
#'
# # validet.Parameters tries to stop the execution, if maleformed arguments are
# provided, which could later blow the quiery.
validate.Parameters = function(params, to.Validate = ""){
  
  if(params[["format"]] == "json" & !requireNamespace("jsonlite", quietly = TRUE)) {
    stop("The package 'jsonlite' is needed...", call. = FALSE)
  }
  
  empty = lapply(to.Validate, function(x){
    nchar(params[[x]]) == 0
  })
  if(!F %in% unlist(empty) & length(unlist(empty)) > 0){
    msg = paste("At least one of these parameters must be given:",
                paste(to.Validate, collapse = " OR "))
    stop(msg)
  }
} 
#' #####
#' Return the API version this package was build for
#'
#' Returns the API version this package was build for, should match with version
#' at \url{http://firebrowse.org/api-docs}.
#'
#' @examples
#' API.Version()
#'
#' @return A character
#'
#' @export
#' #
API.Version = function(){
  number = "1.1.24"
  beta = F
  ret = ifelse(beta, paste("v", number, ":beta", sep=""), paste("v", number, sep=""))
  return(ret)
}


# Forms the version string for the API
reduce.API.Verion = function(version.String){
  version.String = substring(version.String, 1, 2)
  return(version.String)
}

# Return the basic URL
Base.Url = function(){
  return("http://firebrowse.org/api")
}


# Puts together all parameters into string, which is later used to query the API
build.Query = function(parameters, invoker , method, mass = F){
  
  base.URL = Base.Url()
  api.Version = API.Version()
  api.Version = reduce.API.Verion(api.Version)
  
  url = paste(base.URL, api.Version, invoker, method, sep="/")
  if(mass == T){
    idx = which(names(parameters) != "format")
    mass.Q = paste(parameters[[idx]], collapse = "%2C")
    query = paste(mass.Q, "?format=", parameters[["format"]], collapse = "", sep = "")
    query = query[query != ""]
    final.Query = paste(url, "/", paste(unlist(query), collapse = "&"), sep="")
  } else{
    query = lapply(names(parameters), function(nam){
      if(parameters[[nam]][1] != "")
        return(paste(nam, "=", paste(parameters[[nam]], collapse = "%2C"), sep=""))
      else
        return("")
    })
    query = query[query != ""]
    final.Query = paste(url, "?", paste(unlist(query), collapse = "&"), sep="")
  }
  return(final.Query)
}
#' 
#' ##
#' 
#' # This function actually retrives the data, it might be extended if needed
# for other objects
download.Data = function(url, format, page = NULL){
  
  if(exists("page")){
    if(is.null(page)){
      use.Header = T
    } else if(page == ""){
      use.Header = T
    } else if(page == 1){
      use.Header = T
    } else if(page > 1){
      use.Header = F
    }
  } else {
    use.Header = T
  }
  
  response = httr::GET(url)
  if (response$status_code == 200) {
    content = httr::content(response, as="text", encoding="UTF-8")
    connection = textConnection(content)
    if (content != "") {
      # CSV
      if(format == "csv"){
        result = tryCatch({
          read.csv(connection, header = use.Header, stringsAsFactors = F)
        }, warning = function(w) {
          warning(w)
          return(NULL)
        }, error = function(e){
          stop(e)
          return(NULL)
        })
      }
      # TSV
      if(format == "tsv"){
        result = tryCatch({
          read.table(connection, header = use.Header, sep = "\t", quote = "\"", stringsAsFactors = F)
        }, warning = function(w) {
          warning(w)
          return(NULL)
        }, error = function(e){
          stop(e)
          return(NULL)
        })
      }
      # JSON
      if(format == "json"){
        result = tryCatch({
          result = jsonlite::fromJSON(content, simplifyDataFrame = F,
                                      simplifyVector = F,
                                      simplifyMatrix = F)
        }, warning = function(w) {
          warning(w)
          return(NULL)
        }, error = function(e){
          stop(e)
          return(NULL)
        })
        if(length(result[[1]]) == 0 )
          result = NULL
      }
      close(connection)
      return(result)
    } else {
      stop("No samples matching your query")
    }
  } else {
    warning(paste("The API responded with code ", response$status_code),
            ". Your query might be to big", sep="")
  }
  return(NULL)
}
#' 
#' #####
#miRSeq = function( ####
#
devtools::install_github("mariodeng/FirebrowseR")
library(FirebrowseR)
format = "csv"
mirPvalueTex = c("hsa-miR-182-5p","hsa-miR-30c-5p","hsa-miR-30b-5p","hsa-miR-30e-5p","hsa-miR-30d-5p","hsa-miR-20a-5p","hsa-miR-106b-5p","hsa-miR-18a-5p","hsa-miR-18b-5p","hsa-miR-146a-5p","hsa-miR-335-5p","hsa-miR-9-5p","hsa-miR-34a-5p","hsa-miR-210-3p","hsa-miR-27a-3p")
cohort = "HNSC"
tcga_participant_barcode = ""
tool = "miRseq_Mature_Preprocess"
sample_type = "TAM,TAP,TM,TP,TR"
#page = "1"
page_size = 2000
sort_by = "mir"

# save whole_genome/miRNAs in each .Rda?
# #for (i in length(mirPvalueTex)){
for (i in seq(1, length(mirPvalueTex), by=1) ){  
  
all.Found = F
page.Counter = 1
miRNA.Exp = list()
##

while(all.Found == F){
parameters = list(format = format,
                    mir = mirPvalueTex[i],
                    cohort = cohort,
                    tcga_participant_barcode = tcga_participant_barcode,
                    tool = tool,
                    sample_type = sample_type,
                    page = page.Counter,
                    page_size = page_size,
                    sort_by = sort_by)

to.Validate = c("mir")

validate.Parameters(params = parameters, to.Validate = to.Validate)
  
url = build.Query(parameters = parameters,
                    invoker = "Samples",
                    method = "miRSeq")
#  ret = 
miRNA.Exp[[page.Counter]] <- download.Data(url, format, page)
if(nrow(miRNA.Exp[[page.Counter]]) < page_size)
  all.Found = T
else
  page.Counter = page.Counter + 1
} # while loop to get all pages of each miRNA

HNSCC.miRNA.Exp.Fire <- do.call(rbind, miRNA.Exp)
save(HNSCC.miRNA.Exp.Fire, file=paste("HNSCC.miRNA.Exp.", mirPvalueTex[i], ".Fire.Rda", sep=""))
} # end of for i loop
# HNSCC.miRNA.Exp.Fire.Rda x14


# comparing
genePvalueTex <- c("CAMK2N1", "CALML5", "FCGBP")
# *** only get Tumor expression (without normal/blood)
#mRNA.Exp <- download.Data(url, format, page)####
page_size = 2000 # using a bigger page size is faster

for (i in seq(1, length(genePvalueTex), by=1)){

    diff.Exp.Genes <- genePvalueTex[i]
    all.Found = F
    page.Counter = 1
    mRNA.Exp = list()

    while(all.Found == F){
      mRNA.Exp[[page.Counter]] = Samples.mRNASeq(format = "csv",
                                                 gene = diff.Exp.Genes,
                                                 cohort = cohort,
                                                 tcga_participant_barcode = tcga_participant_barcode,
sample_type = sample_type,                                                 page_size = page_size,
page = page.Counter)
      
      if(nrow(mRNA.Exp[[page.Counter]]) < page_size)
        all.Found = T
      else
        page.Counter = page.Counter + 1
    }
    
    HNSCC.mRNA.Exp.Fire = do.call(rbind, mRNA.Exp)
    save(HNSCC.mRNA.Exp.Fire, file=paste("HNSCC.mRNA.Exp.", diff.Exp.Genes, ".Fire.Rda", sep=""))
    #save(HNSCC.mRNA.Exp.Fire, file="HNSCC.mRNA.Exp.Fire.Rda")

} # end of for loop
# HNSCC.mRNA.Exp.Fire.Rda x3
  

# Correlation of expression: miRNA versus mRNA ####
# corr.test()
library(psych)
# CAMK2N1 down-regulation by 
# { hsa-miR-182-5p, -0.18
# with in silico predicted score (), rho[95%CI]
#   hsa-miR-30c-5p (1.000), -0.08
#   hsa-miR-30b-5p (0.999), -0.12
#   hsa-miR-30e-5p (0.998), -0.33[-0.4 -0.33 -0.24]
#   hsa-miR-30d-5p (0.997), -0.25
#   hsa-miR-20a-5p (0.963),-0.12
#   hsa-miR-106b-5p (0.963), -0.24
#   hsa-miR-18a-5p (0.943), -0.02
#   hsa-miR-18b-5p (0.933), -0.21
# }
load(file="HNSCC.mRNA.Exp.CAMK2N1.Fire.Rda") # HNSCC.mRNA.Exp.Fire
y_idx <- (HNSCC.mRNA.Exp.Fire[ ,c(3)] %in% "None")
y<-  HNSCC.mRNA.Exp.Fire[!y_idx ,c(1,3)]
y$expression_log2 <- as.numeric(y$expression_log2)
for (i in seq(1:9)){
  load(file=paste("HNSCC.miRNA.Exp.", mirPvalueTex[i], ".Fire.Rda", sep="")) # HNSCC.miRNA.Exp.Fire
# n= 488 versus 522 => merge by ID
  x_idx <- (HNSCC.miRNA.Exp.Fire[ ,c(3)] %in% "None")
  x<-  HNSCC.miRNA.Exp.Fire[!x_idx ,c(1,3)] # NaN removal
  x$expression_log2 <- as.numeric(x$expression_log2)
# x 488 -> 384
  #
  hnscc_mi_mRNA <- merge(x,y, by="tcga_participant_barcode")
colnames(hnscc_mi_mRNA)[c(2,3)] <- c("expression_log2_miRNA", "expression_log2_mRNA")
cts <- corr.test(hnscc_mi_mRNA[,c(2,3)], use = "pairwise",method="spearman",adjust="holm", 
                 alpha=.05,ci=TRUE,minlength=5) # "spearman" and "kendall", or "pearson"
#cts <- corr.test(hnscc_mi_mRNA$expression_log2_miRNA, hnscc_mi_mRNA$expression_log2_mRNA, use = "pairwise",method="spearman",adjust="holm", alpha=.05,ci=TRUE,minlength=5) # "spearman" and "kendall"
  print(paste(i, ":", mirPvalueTex[i], " targeting to ", genePvalueTex[1], sep="")) # CAMK2N1
#  cts$r #pearson's r or spearman's rho
  print(corr.p(cts$r, n=cts[["n"]]), short=TRUE) 
} # end of loop

#corr.p(cts$r,n=30,adjust="holm",alpha=.05,minlength=5,ci=TRUE)

# 
# CALML5 down-regulation by
# { Spearman's rho
#   hsa-miR-146a-5p, 0.05
#   hsa-miR-335-5p, -0.02
#   hsa-miR-9-5p, 0.16
# }
load(file="HNSCC.mRNA.Exp.CALML5.Fire.Rda") # HNSCC.mRNA.Exp.Fire
y_idx <- (HNSCC.mRNA.Exp.Fire[ ,c(3)] %in% "None")
y<-  HNSCC.mRNA.Exp.Fire[!y_idx ,c(1,3)]
y$expression_log2 <- as.numeric(y$expression_log2)
for (i in c(9+1:11+1)){
  load(file=paste("HNSCC.miRNA.Exp.", mirPvalueTex[i], ".Fire.Rda", sep="")) # HNSCC.miRNA.Exp.Fire
  # n= 488 versus 522 => merge by ID
  x_idx <- (HNSCC.miRNA.Exp.Fire[ ,c(3)] %in% "None")
  x<-  HNSCC.miRNA.Exp.Fire[!x_idx ,c(1,3)] # NaN removal
  x$expression_log2 <- as.numeric(x$expression_log2)
  # x 488 -> 384
  #
  hnscc_mi_mRNA <- merge(x,y, by="tcga_participant_barcode")
  colnames(hnscc_mi_mRNA)[c(2,3)] <- c("expression_log2_miRNA", "expression_log2_mRNA")
  cts <- corr.test(hnscc_mi_mRNA[,c(2,3)], use = "pairwise",method="spearman",adjust="holm", 
                   alpha=.05,ci=TRUE,minlength=5) # "spearman" and "kendall", or "pearson"
  #cts <- corr.test(hnscc_mi_mRNA$expression_log2_miRNA, hnscc_mi_mRNA$expression_log2_mRNA, use = "pairwise",method="spearman",adjust="holm", alpha=.05,ci=TRUE,minlength=5) # "spearman" and "kendall"
  print(paste(i, ":", mirPvalueTex[i], " targeting to ", genePvalueTex[2], sep="")) # CAMK2N1
  #  cts$r #pearson's r or spearman's rho
  print(corr.p(cts$r, n=cts[["n"]]), short=TRUE) 
} # end of loop

# 
# FCGBP down-regulation by
# {, rho
#   hsa-miR-34a-5p, 0.02
#   hsa-miR-210-3p, -0.14
#   hsa-miR-27a-3p, -0.07
# }
load(file="HNSCC.mRNA.Exp.FCGBP.Fire.Rda") # HNSCC.mRNA.Exp.Fire
y_idx <- (HNSCC.mRNA.Exp.Fire[ ,c(3)] %in% "None")
y<-  HNSCC.mRNA.Exp.Fire[!y_idx ,c(1,3)]
y$expression_log2 <- as.numeric(y$expression_log2)
for (i in c(12+1:14+1)){
  load(file=paste("HNSCC.miRNA.Exp.", mirPvalueTex[i], ".Fire.Rda", sep="")) # HNSCC.miRNA.Exp.Fire
  # n= 488 versus 522 => merge by ID
  x_idx <- (HNSCC.miRNA.Exp.Fire[ ,c(3)] %in% "None")
  x<-  HNSCC.miRNA.Exp.Fire[!x_idx ,c(1,3)] # NaN removal
  x$expression_log2 <- as.numeric(x$expression_log2)
  # x 488 -> 384
  #
  hnscc_mi_mRNA <- merge(x,y, by="tcga_participant_barcode")
  colnames(hnscc_mi_mRNA)[c(2,3)] <- c("expression_log2_miRNA", "expression_log2_mRNA")
  cts <- corr.test(hnscc_mi_mRNA[,c(2,3)], use = "pairwise",method="spearman",adjust="holm", 
                   alpha=.05,ci=TRUE,minlength=5) # "spearman" and "kendall", or "pearson"
  #cts <- corr.test(hnscc_mi_mRNA$expression_log2_miRNA, hnscc_mi_mRNA$expression_log2_mRNA, use = "pairwise",method="spearman",adjust="holm", alpha=.05,ci=TRUE,minlength=5) # "spearman" and "kendall"
  print(paste(i, ":", mirPvalueTex[i], " targeting to ", genePvalueTex[3], sep="")) # CAMK2N1
  #  cts$r #pearson's r or spearman's rho
  print(corr.p(cts$r, n=cts[["n"]]), short=TRUE) 
} # end of loop

####################################
ct <- corr.test(attitude)  #find the correlations and give the probabilities
ct #show the results
cts <- corr.test(attitude[1:3],attitude[4:6]) #reports all values corrected for multiple tests

#corr.test(sat.act[1:3],sat.act[4:6],adjust="none")  #don't adjust the probabilities

#take correlations and show the probabilities as well as the confidence intervals
print(corr.p(cts$r,n=484),short=FALSE)  

#don't adjust the probabilities
print(corr.test(sat.act[1:3],sat.act[4:6],adjust="none"),short=FALSE)  

#print out the stars object without showing quotes
print(corr.test(attitude)$stars,quote=FALSE)  #note that the adjusted ps are given as well

